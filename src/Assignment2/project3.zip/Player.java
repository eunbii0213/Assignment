/**
 * This class represents a computer
 * player in the Odd-Even game
 * 
 *  
 */
import java.util.Random; // import Random to create a random number 


public class Player{
    private double t; 
    private int score;

        
    public Player(double threshold){
        t=threshold;
        score=0;
    }
    // If the number is greater than t,
    // the computer will declare “two” if the random number is less than t the computer will declare "one".
    
}