/**
 * This class should run simulations to determine
 * whether or not the Odd-Even game is fair and if
 * not who has the advantage and what is a strategy
 * that will realize that adavantage.
 * 
 * 
 */


public class Simulation{
    
    public static void main(String[] args){
        
        // your code here
        
    }
}