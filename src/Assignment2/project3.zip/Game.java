/**
 * This class represents the Odd-Even game
 * 
 * 
 */

public class Game{
    
    // **** Instance variables

      
    
/* this version of the game constructor is for Part 1
 * it takes no parameters */
    public Game(){
        // your code here
    }
    
/* this version of the game constructor is for Part 2
 * It requires two doubles as parameters. You will use 
 * these to set the initial thresholds for you computer players */
    public Game (double t1, double t2){
        // your code here
    }
    
/* this version of the play method is for Part 1
 * It takes no parameters and should play one interactive
 * version of the game */
    public void play(){
        // your code here
    }
    
    
/** this version of the play method is for Part 2
 * It takes a single int as a parameter which is the
 * number of computer vs. computer games that should be played */
    public void play(int games){
        // your code here
    }

/* this method should return the current score (number of tokens)
 * that player 1 has */
    public int getP1Score(){
        // your code here
        
    }
    
/* this method should return the current score (number of tokens)
 * that player 2 has */
    public int getP2Score(){
        // your code here
        
    }  
    
    
    // you may or may not want more methods here:
    
    
}